package com.jcc.ordersrv;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderSrvApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderSrvApplication.class, args);
	}

}

