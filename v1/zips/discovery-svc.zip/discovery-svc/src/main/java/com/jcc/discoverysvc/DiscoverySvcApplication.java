package com.jcc.discoverysvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DiscoverySvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(DiscoverySvcApplication.class, args);
	}

}

