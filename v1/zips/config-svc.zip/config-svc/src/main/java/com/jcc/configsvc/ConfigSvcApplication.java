package com.jcc.configsvc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ConfigSvcApplication {

	public static void main(String[] args) {
		SpringApplication.run(ConfigSvcApplication.class, args);
	}

}

